bill = input("Wprowadź wysokość rachunku: ")
print ("Napiwek 15% to: ",0.15*int(bill), "\n", "Napiwek 20% to: ",0.2*int(bill))